import React, { useState, useEffect } from 'react';
import { Modal, Button, Form } from 'react-bootstrap';
import { Session } from './types/Session';
import { Booking } from './types/Booking';
import { SeatStatus } from './types/enums';
import { Seat } from './types/Seat';
import axios from './axiosConfig';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Client } from './types/Client';

interface BookingFormProps{
    booking: Booking | null;
    session: Session;
    seat: Seat | undefined;
    rowNumber: number;
    show: boolean;
    onSubmit: (booking: Booking, ticket: TicketDto, ) => void;
    onHide: () => void;
}

export interface TicketDto{
    id: number;
    purchaseDate: string;
    price: number;
    ticketCode: string;
    discountCode?: string;
    clientId?: number;
    sessionId: number;
    seatId: number;
    status: number;
}

const BookingForm: React.FC<BookingFormProps> = ({booking, session, show, rowNumber, seat, onSubmit, onHide}) => {
    const [formData, setFormData] = useState<TicketDto>({
        id: 0,
        purchaseDate: '',
        price: 0,
        ticketCode: '',
        discountCode: '',
        clientId: 0,
        sessionId: session.id,
        seatId: seat? seat.id : 0,
        status: 0
    })
    const [newBooking, setNewBooking] = useState<Booking>({
        id: 0,
        sessionId: session.id,
        seatId: seat? seat.id : 0,
        status: 0
    });
    const [clients, setClients] = useState<Client[]>([]);
    const [isSubmit, setIsSubmit] = useState(false);
    const [isSubmit2, setIsSubmit2] = useState(false);
    const [validated, setValidated] = useState(false);

    useEffect(() =>{
        if (show){
            if (booking) setNewBooking(booking);
            else setNewBooking({
                id: 0,
                sessionId: session.id,
                seatId: seat? seat.id : 0,
                status: 0
            })
            fetchTicket();
        }  
    }, [show]);

    useEffect(() => {
        fetchClients(-1);
    }, []);

    useEffect(() => {
        if (isSubmit){
            handleSubmit();
            setIsSubmit(false);
        }
        if (isSubmit2){
            onSubmit(newBooking, formData);
            setValidated(false);
            setIsSubmit2(false);
            setFormData({
                ...formData,
                id: 0,
                purchaseDate: '',
                price: 0,
                ticketCode: '',
                discountCode: '',
                clientId: 0,
                sessionId: session.id,
                seatId: seat? seat.id : 0,
                status: 0
            });
        }
    }, [formData]);

    const fetchTicket = async() => {
        try{
            if(booking?.status === SeatStatus.Забронировано){
                const response = await axios.get<TicketDto>(`ticket/session?sessionId=${session.id}&seatId=${seat?.id}`);;
                if (response.data) setFormData({
                    ...formData,
                    id: response.data.id,
                    purchaseDate: response.data.purchaseDate,
                    price: response.data.price,
                    ticketCode: response.data.ticketCode,
                    discountCode: response.data.discountCode,
                    clientId: response.data.clientId,
                    sessionId: response.data.sessionId,
                    seatId: response.data.seatId,
                    status: response.data.status
                });
            }            
        }
        catch{
            alert("не удалось получить список занятых мест");
        }
    }

    const fetchClients = async (id: number) => {
        try {
            const response = await axios.get<Client[]>(`client?id=${id}`);
            setClients(response.data);
        } catch {
            alert('Не удалось загрузить список клиентов');
        }
    };
    const handleStatusChange = (newStatus: number) => {
        setNewBooking({
            ...newBooking,
            status: newStatus
        });
        setFormData({
            ...formData,
            status: newStatus
        })
        setIsSubmit(true);
    }

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = e.target;
        setFormData({
            ...formData,
            [name]: name === "price" ? parseFloat(value) : value
        });
    };

    const handleSubmit = () => {
        if (formData.price) {
            const currentDate = new Date();
            const year = currentDate.getFullYear();
            const month = String(currentDate.getMonth() + 1).padStart(2, '0');
            const day = String(currentDate.getDate()).padStart(2, '0');
            const dateString = `${year}-${month}-${day}`;
            setIsSubmit2(true);
            setFormData({
                ...formData,
                seatId: seat ? seat.id : 0,
                clientId: clients.length === 1 || formData.clientId === 0 ? clients[0].id: formData.clientId,
                purchaseDate: dateString,
                ticketCode: `sessionid${formData.sessionId}seatid${formData.seatId}clientid${formData.clientId}discountcode${formData.discountCode}`
            })
            
        } else {
            alert('Не все обязательные поля заполнены');
        }
        setValidated(true);
    };

    return(
        <Modal show={show} onHide={onHide} centered>
            <Modal.Header closeButton>
                <Modal.Title>Ряд {rowNumber}, место {seat?.number}</Modal.Title>
            </Modal.Header>
            <div style={{fontSize:"20px", marginLeft:"15px"}}><strong>Статус:</strong> {booking? SeatStatus[booking.status]: SeatStatus[0]}</div>
            <div style={{fontSize:"18px", marginLeft:"15px"}}><strong>Стоимость взрослого билета:</strong> {session.priceAdult}</div>
            <div style={{fontSize:"18px", marginLeft:"15px"}}><strong>Стоимость детского билета:</strong> {session.priceChild}</div>
            {newBooking.status == 0 && <Modal.Body>
                <h5>Обязательные поля отмечены *</h5>
                <Form noValidate validated={validated}>
                    <Form.Group>
                        <Form.Label>Скидочный код</Form.Label>
                        <Form.Control
                            type="text"
                            name="discountCode"
                            value={formData.discountCode}
                            onChange={handleChange}
                        />
                    </Form.Group>
                    <Form.Group>
                        <Form.Label>Итоговая стоимость билета*</Form.Label>
                        <Form.Control
                            type="number"
                            name="price"
                            value={formData.price}
                            onChange={handleChange}
                            required
                        />
                    </Form.Group>
                    <Form.Group>
                        <Form.Label>ID клиента*</Form.Label>
                        <Form.Select
                                name='clientId'
                                value={formData.clientId}
                                onChange={(e) => setFormData({ ...formData, clientId: parseInt(e.target.value) })}
                                required
                            >
                                {clients.map((client) => (
                                <option key={client.id} value={client.id}>
                                    {client.id}
                                </option>
                                ))}
                        </Form.Select>
                    </Form.Group>
                </Form>
            </Modal.Body>}
            <Modal.Footer>
            {booking ? (
                <>
                    {booking.status === 0 && (
                        <>
                            <Button onClick={() => handleStatusChange(2)} variant='danger'>Купить</Button>
                            <Button onClick={() => handleStatusChange(1)} variant='primary'>Забронировать</Button>
                        </>
                    )}
                    {booking.status === 1 && (
                        <>
                            <Button onClick={() => handleStatusChange(0)} variant='danger'>Отменить бронь</Button>
                            <Button onClick={() => handleStatusChange(2)} variant='primary'>Подтвердить бронь</Button>
                        </>
                    )}
                </>
            ) : (
                <>
                    <Button onClick={() => handleStatusChange(2)} variant='danger'>Купить</Button>
                    <Button onClick={() => handleStatusChange(1)} variant='primary'>Забронировать</Button>
                </>
            )}
            </Modal.Footer>
        </Modal>
    );
}

export default BookingForm;
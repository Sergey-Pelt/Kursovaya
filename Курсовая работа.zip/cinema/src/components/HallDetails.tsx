import React, { useState } from 'react';
import { Button, Stack } from 'react-bootstrap';
import { Hall } from './types/Hall';
import { Row } from './types/Row';
import HallForm from './HallForm';
import 'bootstrap/dist/css/bootstrap.min.css';

interface HallDetailProps {
    hall: Hall;
    rows: Row[];
    onSave: () => void;
    onDelete: () => void;
    onBack: () => void;
}

const HallDetail: React.FC<HallDetailProps> = ({ hall, rows, onSave, onDelete, onBack }) => {
    const [showForm, setShowForm] = useState(false);
    const [hallName, setHallName] = useState(hall.name);

    const handleSave = async (name: string | null) => {
        setShowForm(false);
        onSave();
        name ? setHallName(name) : setHallName("");
    };

    return (
        <div>
            <Button style={{marginBottom:10}} variant="outline-secondary" onClick={onBack}>Назад</Button>
            <Stack gap={2} style={{fontSize: 20} }>
                <div><strong>{hallName}</strong></div>
                <div style={{
                    border: '3px solid darkgray',
                    padding: '10px',
                    marginTop: '10px',
                    width: '10',
                    borderRadius: 10
                }}>
                    <div style={{
                        border: '3px solid darkgray',
                        borderRadius: 5,
                        display: 'flex',
                        justifyContent: 'center',
                        alignItems: 'center',
                        backgroundColor: 'lightgray',
                        padding: '10px',
                        marginBottom: '10px',
                        width: '10'
                    }}>
                        <div style={{fontSize: '25px', color: 'gray'}}><strong>Экран</strong></div>
                    </div>
                    {rows.map(row => (
                        <div key={row.id} style={{
                            display: 'flex',
                            justifyContent: 'center',
                            flexWrap: 'wrap',
                            marginBottom: '10px',
                            fontSize: 15,
                            textAlign: 'left',
                            color:'gray'
                        }}><strong>{row.number}</strong>
                        {row.seats.filter(seat => seat.rowId === row.id).map(seat => (
                            <div 
                            key={seat.id} 
                            style={{
                                width: '20px',
                                height: '20px',
                                borderRadius: 5,
                                border: '2px solid darkgray',
                                backgroundColor: 'lightgray',
                                margin: '2px',
                                flexShrink: 1,
                                fontSize: 10,
                                textAlign: 'center',
                                color:'gray'
                            }}
                        >{seat.number}</div>
                    ))}
                    </div>
                ))}
                </div>
                <Stack direction='horizontal' gap={2}>
                    <Button onClick={() => setShowForm(true)}>Редактировать</Button>
                    <Button variant="danger" onClick={onDelete}>Удалить</Button>
                </Stack>
            </Stack>
            <HallForm
                show={showForm}
                onHide={() => setShowForm(false)}
                onSave={handleSave}
                hall={hall}
                rows={rows}
            />
        </div>
    );
};

export default HallDetail;
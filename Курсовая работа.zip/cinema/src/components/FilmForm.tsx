import React, { useState, useEffect } from 'react';
import { Modal, Button, Form, Stack } from 'react-bootstrap';
import { Film } from './types/Film';
import { Genre } from './types/enums';
import 'bootstrap/dist/css/bootstrap.min.css';

interface FilmFormProps {
    show: boolean;
    film: Film | null;
    onSubmit: (Film: Film) => void;
    onHide: () => void;
}

const genreOptions = Object.values(Genre).filter(value => typeof value === 'string') as string[];

const FilmForm: React.FC<FilmFormProps> = ({ show, film, onSubmit, onHide }) => {
    const [formData, setFormData] = useState<Film>({
        id: 0,
        name: '',
        description: '',
        duration: '00:00',
        minimalAge: 0,
        genre: 0
    });
    const [validated, setValidated] = useState(false);

    useEffect(() => {
        if (film) {
            setFormData(film);
        } else {
            setFormData({
                id: 0,
                name: '',
                description: '',
                duration: '00:00',
                minimalAge: 0,
                genre: 0
            });
        }
    }, [film]);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = e.target;
        setFormData({
            ...formData,
            [name]: value
        });
    };

    const handleGenreChange = (event: React.ChangeEvent<HTMLSelectElement>) => {
        const value = event.target.value;
        setFormData({ ...formData, genre: parseInt(value)});
    };

    const handleSubmit = (e: React.ChangeEvent<HTMLFormElement>) => {
        e.preventDefault();
        setValidated(true);
        const form = e.currentTarget;
        if (form.checkValidity() === false) {
            e.stopPropagation();
        }
        else{
            onSubmit(formData);
            setValidated(false);
            film = null;
        }
    };

    return (
        <Modal show={show} onHide={onHide} centered>
            <Modal.Header closeButton>
                <Modal.Title>{film ? 'Редактировать фильм' : 'Добавить фильм'}</Modal.Title>
            </Modal.Header>
            <Modal.Body>
            <h5>Обязательные поля отмечены *</h5>
                <Form noValidate validated={validated} onSubmit={handleSubmit}>
                    <Form.Group>
                        <Form.Label>Название*</Form.Label>
                        <Form.Control
                            type="text"
                            name="name"
                            value={formData.name}
                            onChange={handleChange}
                            required
                        />
                    </Form.Group>
                    <Form.Group>
                        <Form.Label>Описание</Form.Label>
                        <Form.Control
                            type="text"
                            name="description"
                            value={formData.description}
                            onChange={handleChange}
                            required
                        />
                    </Form.Group>
                    <Form.Group>
                        <Form.Label>Продолжительность*</Form.Label>
                        <Form.Control
                            type="time"
                            name="duration"
                            value={formData.duration || ''}
                            onChange={handleChange}
                            required
                        />
                    </Form.Group>
                    <Form.Group>
                        <Form.Label>Возрастное ограничение*</Form.Label>
                        <Form.Control
                            type="number"
                            name="minimalAge"
                            value={formData.minimalAge}
                            onChange={handleChange}
                            required
                        />
                    </Form.Group>
                    <Form.Group>
                        <Form.Label>Жанр*</Form.Label>
                        <Form.Select
                            name="genre"
                            value={formData.genre}
                            onChange={handleGenreChange}
                            required
                        >
                            {genreOptions.map((key, index) => (
                                <option key={index} value={index}>
                                    {Genre[index]}
                                </option>
                            ))}
                        </Form.Select>
                    </Form.Group>
                    <Stack direction='horizontal' gap={2} style={{paddingTop: 10}}>
                        <Button variant="secondary" onClick={onHide}>Отмена</Button>
                        <Button variant="primary" type='submit'>Сохранить</Button>
                    </Stack>
                </Form>
            </Modal.Body>
        </Modal>
    );
};

export default FilmForm;
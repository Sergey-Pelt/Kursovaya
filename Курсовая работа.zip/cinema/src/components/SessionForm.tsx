import React, { useState, useEffect } from 'react';
import { Modal, Button, Form } from 'react-bootstrap';
import { Session } from './types/Session';
import axios from './axiosConfig';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Hall } from './types/Hall';

interface SessionFormProps {
    show: boolean;
    session: Session | null;
    onSubmit: (session: Session) => void;
    onHide: () => void;
}

export interface SessionDto {
    id: number;
    time: string;
    date: string;
    priceAdult: number;
    priceChild?: number;
    hallId: number;
    filmId: number;
}

const SessionForm: React.FC<SessionFormProps> = ({ show, session, onSubmit, onHide }) => {
    const [formData, setFormData] = useState<SessionDto>({
        id: 0,
        time: '',
        date: '',
        priceAdult: 0,
        priceChild: 0,
        hallId: 0,
        filmId: 0
    });
    const [halls, setHalls] = useState<Hall[]>([]);
    const [isSubmit, setSubmit] = useState(false);
    const [validated, setValidated] = useState(false);

    useEffect(() => {
        fetchHalls(-1);
    }, []);

    useEffect(() => {
        if (isSubmit){
            if (formData?.time && formData.date && formData.hallId) {
                onSubmit(formData);
                setValidated(false);
            } else {
                alert('Не все обязательные поля заполнены');
            }
        }
        setSubmit(false);
    }, [formData])

    const fetchHalls = async (id: number) => {
        try {
            const response = await axios.get<Hall[]>(`hall?id=${id}`);
            setHalls(response.data);
        } catch (error) {
           alert('Не удалось загрузить список залов');
        }
    };

    useEffect(() => {
        if (session) {
            setFormData(session);
        } else {
            setFormData({
                id: 0,
                time: '',
                date: '',
                priceAdult: 0,
                priceChild: 0,
                hallId: 0,
                filmId: 0
            });
        }
    }, [session]);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = e.target;
        setFormData({
            ...formData,
            [name]: value
            
        });
    };

    const handleSubmit = () => {
        setValidated(true);
        if (halls.length === 1 || ( formData.hallId === 0 && halls.length > 0)){
            setFormData({
                ...formData,
                hallId: halls[0].id
            })
        }
        else {
            onSubmit(formData);
            setValidated(false);
        }
        setSubmit(true);
        
    };

    return (
        <Modal show={show} onHide={onHide} centered>
            <Modal.Header closeButton>
                <Modal.Title>{session ? 'Редактировать сеанс' : 'Добавить сеанс'}</Modal.Title>
            </Modal.Header>
            <Modal.Body>
            <h5>Обязательные поля отмечены *</h5>
                <Form noValidate validated={validated}>
                    <Form.Group>
                        <Form.Label>Дата*</Form.Label>
                        <Form.Control
                            type="date"
                            name="date"
                            value={formData.date}
                            onChange={handleChange}
                            required
                        />
                    </Form.Group>
                    <Form.Group>
                        <Form.Label>Время начала*</Form.Label>
                        <Form.Control
                            type="time"
                            name="time"
                            value={formData.time}
                            onChange={handleChange}
                            required
                        />
                    </Form.Group>
                    <Form.Group>
                        <Form.Label>Цена за взрослый билет*</Form.Label>
                        <Form.Control
                            type="number"
                            name="priceAdult"
                            value={formData.priceAdult}
                            onChange={handleChange}
                            required
                        />
                    </Form.Group>
                    <Form.Group>
                        <Form.Label>Цена за детский билет</Form.Label>
                        <Form.Control
                            type="number"
                            name="priceChild"
                            value={formData.priceChild}
                            onChange={handleChange}
                            
                        />
                    </Form.Group>
                    {session ? (
                        <></>
                    ): (
                        <Form.Group>
                            <Form.Label>Зал*</Form.Label>
                            <Form.Select
                                name='hallId'
                                value={formData.hallId}
                                onChange={(e) => setFormData({ ...formData, hallId: parseInt(e.target.value) })}
                            >
                                {halls.map((hall) => (
                                <option key={hall.id} value={hall.id}>
                                    {hall.name}
                                </option>
                                ))}
                            </Form.Select>
                        </Form.Group>
                    )}
                    
                </Form>
            </Modal.Body>
            <Modal.Footer>
                <Button variant="secondary" onClick={onHide}>Отмена</Button>
                <Button variant="primary" onClick={handleSubmit}>Сохранить</Button>
            </Modal.Footer>
        </Modal>
    );
};

export default SessionForm;
import React from 'react';
import { Button, Stack } from 'react-bootstrap';
import { Film } from './types/Film'; 
import { Genre } from './types/enums';
import SessionList from './SessionList';
import 'bootstrap/dist/css/bootstrap.min.css';

interface FilmDetailsProps {
    film: Film;
    onEdit: (film: Film) => void;
    onDelete: (id: number) => void;
    onBack: () => void;
}

const FilmDetails: React.FC<FilmDetailsProps> = ({ film, onEdit, onDelete, onBack }) => {

    return (
        <div>
            <Stack gap={1} style={{fontSize: 20} }>
                <div><Button variant="outline-secondary" onClick={onBack}>К списку фильмов</Button></div>
                <h2>Информация о фильме</h2>
                <div><strong>{film.name}</strong> {film.minimalAge}+</div>
                <div>{film.description}</div>
                <div><strong>Продолжительность:</strong> {film.duration}</div>
                <div><strong>Жанр:</strong> {Genre[film.genre]}</div>
                <Stack direction='horizontal' gap={1}>
                    <Button variant="primary" onClick={() => onEdit(film)}>Редактировать</Button>
                    <Button variant="danger" onClick={() => onDelete(film.id)}>Удалить</Button>
                </Stack>
                <SessionList film={film}/>
            </Stack>
        </div>
    );
};

export default FilmDetails;
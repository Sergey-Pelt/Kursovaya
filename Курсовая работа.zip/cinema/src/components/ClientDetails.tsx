import React from 'react';
import { Button, Stack } from 'react-bootstrap';
import { Client } from './types/Client'; 
import TicketList from './TicketList';

import 'bootstrap/dist/css/bootstrap.min.css';

interface ClientDetailsProps {
    client: Client;
    onEdit: (client: Client) => void;
    onDelete: (id: number) => void;
    onBack: () => void;
}

const ClientDetails: React.FC<ClientDetailsProps> = ({ client, onEdit, onDelete, onBack }) => {
    

    return (
        <div>
            <Button variant="outline-secondary" onClick={onBack}>Назад</Button>
            <Stack gap={1} style={{fontSize: 20} }>
                <h2>Информация о клиенте</h2>
                <div><strong>Имя:</strong> {client.name}</div>
                <div><strong>Фамилия:</strong> {client.surname}</div>
                <div><strong>Отчество:</strong> {client.patronymic}</div>
                <div><strong>Дата рождения:</strong> {client.birthdate}</div>
                <div><strong>Email:</strong> {client.email}</div>
                <div><strong>Номер телефона:</strong> {client.phone}</div>
                <Stack direction='horizontal' gap={2}>
                    <Button variant="primary" onClick={() => onEdit(client)}>Редактировать</Button>
                    <Button variant="danger" onClick={() => onDelete(client.id)}>Удалить</Button>
                </Stack>
                <TicketList client={client} />
            </Stack>
        </div>
    );
};

export default ClientDetails;
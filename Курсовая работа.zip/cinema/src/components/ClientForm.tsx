import React, { useState, useEffect } from 'react';
import { Modal, Button, Form, Stack } from 'react-bootstrap';
import { Client } from './types/Client';
import 'bootstrap/dist/css/bootstrap.min.css';

interface ClientFormProps {
    show: boolean;
    client: Client | null;
    onSubmit: (client: Client) => void;
    onHide: () => void;
}

const ClientForm: React.FC<ClientFormProps> = ({ show, client, onSubmit, onHide }) => {
    const [formData, setFormData] = useState<Client>({
        id: 0,
        name: '',
        surname: '',
        patronymic: undefined,
        birthdate: '',
        email: '',
        phone: ''
    });
    const [validated, setValidated] = useState(false);

    useEffect(() => {
        if (client) {
            setFormData(client);
        } else {
            setFormData({
                id: 0,
                name: '',
                surname: '',
                patronymic: undefined,
                birthdate: '',
                email: '',
                phone: ''
            });
        }
    }, [client]);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = e.target;
        setFormData({
            ...formData,
            [name]: value
        });
    };

    const handleSubmit = (e: React.ChangeEvent<HTMLFormElement>) => {
        e.preventDefault();
        setValidated(true);
        const form = e.currentTarget;
        if (form.checkValidity() === false) {
            e.stopPropagation();
        }
        else {
            onSubmit(formData);
            setValidated(false);
            client = null;
        }
    };

    return (
        <Modal show={show} onHide={onHide} centered>
            <Modal.Header closeButton>
                <Modal.Title>{client ? 'Редактировать клиента' : 'Добавить клиента'}</Modal.Title>
            </Modal.Header>
            <Modal.Body>
            <h5>Обязательные поля отмечены *</h5>
                <Form noValidate validated={validated} onSubmit={handleSubmit}>
                    <Form.Group>
                        <Form.Label>Имя*</Form.Label>
                        <Form.Control
                            type="text"
                            name="name"
                            value={formData.name}
                            onChange={handleChange}
                            required
                        />
                    </Form.Group>
                    <Form.Group>
                        <Form.Label>Фамилия*</Form.Label>
                        <Form.Control
                            type="text"
                            name="surname"
                            value={formData.surname}
                            onChange={handleChange}
                            required
                        />
                    </Form.Group>
                    <Form.Group>
                        <Form.Label>Отчество</Form.Label>
                        <Form.Control
                            type="text"
                            name="patronymic"
                            value={formData.patronymic || ''}
                            onChange={handleChange}
                        />
                    </Form.Group>
                    <Form.Group>
                        <Form.Label>Дата рождения*</Form.Label>
                        <Form.Control
                            type="date"
                            name="birthdate"
                            value={formData.birthdate}
                            onChange={handleChange}
                            required
                        />
                    </Form.Group>
                    <Form.Group>
                        <Form.Label>Email*</Form.Label>
                        <Form.Control
                            type="email"
                            name="email"
                            value={formData.email}
                            onChange={handleChange}
                            required
                        />
                    </Form.Group>
                    <Form.Group>
                        <Form.Label>Ноемр телефона*</Form.Label>
                        <Form.Control
                            type="text"
                            name="phone"
                            value={formData.phone}
                            onChange={handleChange}
                            required
                        />
                    </Form.Group>
                    <Stack direction='horizontal' gap={2} style={{paddingTop: 10}}>
                        <Button variant="secondary" onClick={onHide}>Отмена</Button>
                        <Button variant="primary" type='submit'>Сохранить</Button>
                    </Stack>
                </Form>
            </Modal.Body>      
        </Modal>
    );
};

export default ClientForm;
import React from 'react';
import { Stack, Button } from 'react-bootstrap';
import { Employee } from './types/Employee';
import 'bootstrap/dist/css/bootstrap.min.css';

interface EmployeeDetailsProps {
    employee: Employee;
    onEdit: (employee: Employee) => void;
    onDelete: (id: number) => void;
    onBack: () => void;
}

const EmployeeDetails: React.FC<EmployeeDetailsProps> = ({ employee, onEdit, onDelete, onBack }) => {
    return (
        <div>
            <Button variant="outline-secondary" onClick={onBack}>Назад</Button>
            <Stack gap={1} style={{fontSize: 20} }>
                <h2>Информация о сотруднике</h2>
                <div><strong>Имя:</strong> {employee.name}</div>
                <div><strong>Фамилия:</strong> {employee.surname}</div>
                <div><strong>Отчество:</strong> {employee.patronymic}</div>
                <div><strong>Дата рождения:</strong> {employee.birthdate}</div>
                <div><strong>Email:</strong> {employee.email}</div>
                <div><strong>Номер телефона:</strong> {employee.phone}</div>
                <div><strong>Должность:</strong> {employee.position}</div>
                <div><strong>Заработная плата:</strong> {employee.salary}</div>
                <Stack direction='horizontal' gap={2}>
                    <Button variant="primary" onClick={() => onEdit(employee)}>Редактировать</Button>
                    <Button variant="danger" onClick={() => onDelete(employee.id)}>Удалить</Button>
                </Stack> 
            </Stack>            
        </div>
    );
};

export default EmployeeDetails;

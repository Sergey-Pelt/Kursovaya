import React, { useState, useEffect } from 'react';
import { ListGroup, Button } from 'react-bootstrap';
import axios from './axiosConfig';
import { Employee } from './types/Employee';
import EmployeeDetails from './EmployeeDetails';
import EmployeeForm from './EmployeeForm';
import 'bootstrap/dist/css/bootstrap.min.css';

const EmployeeList: React.FC = () => {
    const [employees, setEmployees] = useState<Employee[]>([]);
    const [selectedEmployee, setSelectedEmployee] = useState<Employee | null>(null);
    const [showForm, setShowForm] = useState<boolean>(false);
    const [isEdit, setIsEdit] = useState<boolean>(false);

    useEffect(() => {
        fetchEmployees(-1);
    }, []);


    const fetchEmployees = async (id: number) => {
        try {
            const response = await axios.get<Employee[]>(`employee?id=${id}`);
            setEmployees(response.data);
        } catch {
            alert('Не удалось загрузить список сотрудников');
        }
    };

    const handleAddEmployee = () => {
        setSelectedEmployee(null);
        setIsEdit(false);
        setShowForm(true);
    };

    const handleEditEmployee = (employee: Employee) => {
        setSelectedEmployee(employee);
        setIsEdit(true);
        setShowForm(true);
    };

    const handleDeleteEmployee = async (id: number) => {
        try {
            await axios.delete(`employee?id=${id}`);
            fetchEmployees(-1);
            setSelectedEmployee(null);
        } catch {
            alert('Не удалось удалить сотрудника');
        }
    };

    const handleFormSubmit = async (employee: Employee) => {
        if (isEdit) {
            try {
                await axios.put(`employee?id=${employee.id}`, employee);
            }
            catch {
                alert("Введены неверные или уже существующие данные")
            }
        } else {
            try {
                await axios.post('employee', employee);
            }
            catch {
                alert("Введены неверные или уже существующие данные")
            }
        }
        fetchEmployees(-1);
        setShowForm(false);
        if (isEdit) setSelectedEmployee(employee); 
    };

    return (
        <div>
            {selectedEmployee ? (
                <EmployeeDetails
                    employee={selectedEmployee}
                    onEdit={handleEditEmployee}
                    onDelete={handleDeleteEmployee}
                    onBack={() => setSelectedEmployee(null)}
                />
            ) : (
                <div>
                    <h2>Список сотрудников</h2>
                    <div style={{border:'1px solid darkgray', borderRadius: 5, height: 2, backgroundColor: 'darkgray', marginTop: 10, marginBottom: 13}}></div>
                    <Button style={{marginBottom:10}} variant="primary" onClick={handleAddEmployee}>Добавить сотрудника</Button>
                    <ListGroup>
                        {employees.map(employee => (
                            <ListGroup.Item key={employee.id} action onClick={() => setSelectedEmployee(employee)}>
                                <div>{`${employee.surname} ${employee.name} ${employee.patronymic || ''}`}</div>
                                <div>{employee.position}</div>
                            </ListGroup.Item>
                        ))}
                    </ListGroup>
                </div>
            )}
            <EmployeeForm
                show={showForm}
                employee={selectedEmployee}
                onSubmit={handleFormSubmit}
                onHide={() => setShowForm(false)}
            />
        </div>
    );
};

export default EmployeeList;
import React, { useState, useEffect } from 'react';
import { Button, ListGroup, Stack } from 'react-bootstrap';
import { Session } from './types/Session'
import { Film } from './types/Film';
import SessionDetails from './SessionDetails';
import SessionForm from './SessionForm';
import { SessionDto } from './SessionForm';
import axios from './axiosConfig';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Row } from './types/Row';
import { Seat } from './types/Seat';

interface SessionListProps {
    film: Film;
}

const SessionList: React.FC<SessionListProps> = ({ film  }) => {
    const [sessions, setSessions] = useState<Session[]>([]);
    const [selectedSession, setSelectedSession] = useState<Session | null>(null);
    const [showForm, setShowForm] = useState<boolean>(false);
    const [isEdit, setIsEdit] = useState<boolean>(false);
    const [isRowsSet, setIsRowsSet] = useState(false);
    const [rows, setRows] = useState<Row[]>([]);
    const [session, setSession] = useState<Session | null>(null);

    
    const handleAddSession = () => {
        setSelectedSession(null);
        setIsEdit(false);
        setShowForm(true);
    };

    const handleEditSession = (session: Session) => {
        setSelectedSession(session);
        setIsEdit(true);
        setShowForm(true);
    }

    useEffect(() => {
        fetchSessions();
    }, []);

    useEffect(() => {
        if (isRowsSet) {
            setSelectedSession(session);
            setIsRowsSet(false);
        }
    }, [isRowsSet, rows]);

    const fetchSessions = async () => {
        try {
            const response = await axios.get<Session[]>(`session/film?filmId=${film.id}`);
            setSessions(response.data);
        } catch (error) {
            alert('Не удалось загрузить список сеансов');
        }
    };

    const handleDeleteSession = async (id: number) => {
        try {
            await axios.delete(`session?id=${id}`);
            fetchSessions();
            setSelectedSession(null);
        } catch (error) {
            alert('Невозможно удалить сеанс, так как на него уже куплены билеты');
        }
    }

    const handleShowDetails = (session: Session) => {
        fetchRowsAndSeats(session.hallId);
        setSession(session);
    }

    const handleFormSubmit = async (session: SessionDto) => {
        session.filmId = film.id;
        if (isEdit) {
            try {
                await axios.put(`session?id=${session.id}`, session);
            }
            catch {
                alert("Введены неверные или уже существующие данные")
            }
        } else {
            try {
                await axios.post('session', session);
            }
            catch {
                alert("Введены неверные или уже существующие данные")
            }
        }
        setShowForm(false);
        if (isEdit) setSelectedSession(session);
        fetchSessions();
    };

    const fetchRowsAndSeats = async (hallId: number) => {
        try {
            await axios.get<Row[]>(`row/hall?hallId=${hallId}`)
            .then(async (response) =>
            {
                const tempRows = response.data;
                const rowsWithSeatsPromises = await Promise.all(tempRows.map(async (row) => {
                    const seatsResponse = await axios.get<Seat[]>(`seat/row?rowId=${row.id}`);
                    const seats = seatsResponse.data;
                    return { ...row, seats };
            }));
            const rowsWithSeats = await Promise.all(rowsWithSeatsPromises);
            setRows(rowsWithSeats);
            setIsRowsSet(true);
            })
        } catch (error) {
            alert('Не удалось получить данные');
        }
    };

    return (
        <div style={{fontSize:16}}>
            <div style={{border:'1px solid darkgray', borderRadius: 5, height: 2, backgroundColor: 'darkgray', marginTop: 10, marginBottom: 13}}></div>
            {sessions.length === 0 ? (
                <Stack gap={1}>
                    <h2>Доступные сеансы</h2>
                    <div><Button variant="primary" onClick={handleAddSession}>Добавить сеанс</Button></div>
                    <h4>Сеансов не найдено.</h4>
                </Stack>  
            ) : (
                <div>
                    { selectedSession ? (
                        <SessionDetails
                            session={selectedSession}
                            rows={rows}
                            onEdit={handleEditSession}
                            onDelete={handleDeleteSession}
                            onBack={() => setSelectedSession(null)}
                        />
                    ) : (
                        <Stack gap={1}>
                            <h2>Доступные сеансы</h2>
                            <div><Button variant="primary" onClick={handleAddSession}>Добавить сеанс</Button></div>
                            <ListGroup>
                                {sessions.map(session => (
                                    <ListGroup.Item key={session.id} action onClick={() => handleShowDetails(session)}>
                                        <div>{`${session.hall?.name} `}</div>
                                        <div>{session.time} {session.date}</div>
                                    </ListGroup.Item>
                                ))}
                            </ListGroup>
                        </Stack>
                    )}
                </div>
            )}
            <SessionForm
                show={showForm}
                session={selectedSession}
                onSubmit={handleFormSubmit}
                onHide={() => setShowForm(false)}
            />
        </div>
    );
};

export default SessionList;
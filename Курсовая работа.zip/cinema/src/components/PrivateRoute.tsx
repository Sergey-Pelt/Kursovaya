import { Navigate, Outlet } from 'react-router-dom';
import { useSelector, useDispatch } from 'react-redux';
import { RootState } from "../store";
import React, { useEffect } from 'react';
import { login } from './authSlice';

const PrivateRoute:React.FC = () => {
  const wasAuthenticated = localStorage.getItem('isAuthenticated') === 'true';
  const { isAuthenticated } = useSelector((state: RootState) => state.auth);
  const dispatch = useDispatch();

  useEffect(() => {
    Login();
  }, []);

  const Login = () => {
    if (wasAuthenticated) dispatch(login({user: localStorage.getItem('user')}))
  }

  return (
    <div>
      {isAuthenticated || wasAuthenticated ? (
          <Outlet/>
      ) : (
        <Navigate to="/login" />
      )}
    </div>
  );
};

export default PrivateRoute;

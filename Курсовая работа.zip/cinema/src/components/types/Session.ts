import { Film } from "./Film";
import { Hall } from "./Hall";

export interface Session {
    id: number;
    time: string;
    date: string;
    priceAdult: number;
    priceChild?: number;
    hallId: number;
    filmId: number;
    film?: Film;
    hall?: Hall;
}
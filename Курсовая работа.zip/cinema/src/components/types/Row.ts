import { Hall } from "./Hall";
import { Seat } from "./Seat";

export interface Row {
    seats: Seat[];
    id: number;
    hallId: number;
    number: number;
    hall: Hall;
}

import { Row } from "./Row";

export interface Seat {
    id: number;
    number: number;
    rowId: number;
    row: Row;
}

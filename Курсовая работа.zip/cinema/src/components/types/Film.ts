import { Genre } from './enums';

export interface Film {
    id: number;
    name: string;
    description?: string;
    duration?: string;
    genre: Genre;
    minimalAge: number;
}

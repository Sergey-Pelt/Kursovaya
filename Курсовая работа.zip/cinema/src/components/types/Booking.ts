export interface Booking {
    id: number;
    status: number;
    sessionId: number;
    seatId: number;
}
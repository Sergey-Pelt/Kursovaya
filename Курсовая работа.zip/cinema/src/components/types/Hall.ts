export interface Hall {
    id: number;
    name: string;
}

import { Session } from './Session';
import { TicketStatus } from './enums';
import { Seat } from './Seat';

export interface Ticket {
    id: number;
    purchaseDate: string;
    price: number;
    ticketCode: string;
    discountCode?: string;
    clientId?: number;
    sessionId: number;
    seatId: number;
    status: TicketStatus;
    seat: Seat;
    session: Session;
}
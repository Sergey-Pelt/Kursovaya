export interface Employee {
    id: number;
    name: string;
    surname: string;
    patronymic?: string;
    birthdate: string;
    email: string;
    phone: string;
    position: string;
    salary: number;
}

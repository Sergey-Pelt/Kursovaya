import React, { useState, useEffect } from 'react';
import { Button, ListGroup } from 'react-bootstrap';
import HallDetail from './HallDetails';
import axios from './axiosConfig';
import { Hall } from './types/Hall';
import { Row } from './types/Row';
import { Seat } from './types/Seat';
import 'bootstrap/dist/css/bootstrap.min.css';
import HallForm from './HallForm';

const HallManager: React.FC = () => {
    const [halls, setHalls] = useState<Hall[]>([]);
    const [selectedHall, setSelectedHall] = useState<Hall | null>(null);
    const [rows, setRows] = useState<Row[]>([]);
    const [showForm, setShowForm] = useState(false);
    const [isRowsSet, setIsRowsSet] = useState(false);
    const [hall, setHall] = useState<Hall | null>(null);

    useEffect(() => {
        fetchHalls(-1);
    }, []);
    
    useEffect(() => {
        if (isRowsSet) {
            setSelectedHall(hall);
            setIsRowsSet(false);
        }
    }, [isRowsSet, rows]);

    const fetchHalls = async (id: number) => {
        try {
            const response = await axios.get<Hall[]>(`hall?id=${id}`);
            setHalls(response.data);
        } catch {
            alert('Не удалось загрузить залы');
        }
    };

    const fetchRowsAndSeats = async (hallId: number) => {
        try {
            await axios.get<Row[]>(`row/hall?hallId=${hallId}`)
            .then(async (response) =>
            {
                const tempRows = response.data;
                const rowsWithSeatsPromises = await Promise.all(tempRows.map(async (row) => {
                    const seatsResponse = await axios.get<Seat[]>(`seat/row?rowId=${row.id}`);
                    const seats = seatsResponse.data;
                    return { ...row, seats };
            }));
            const rowsWithSeats = await Promise.all(rowsWithSeatsPromises);
            setRows(rowsWithSeats);
            setIsRowsSet(true);
            })
        } catch {
            alert('Не удалось загрузить данные');
        }
    };

    const handleSelectHall = async (newHall: Hall) => {
        setHall(newHall);
        fetchRowsAndSeats(newHall.id);
        
    };

    const handleSave = () => {
        fetchHalls(-1);
        setSelectedHall(null);
        setSelectedHall(halls[halls.length - 1])
    };

    const handleDelete = async () => {
        if (selectedHall) {
            try {
                await axios.delete(`hall?id=${selectedHall.id}`);
                fetchHalls(-1);
                setSelectedHall(null);
            } catch {
                alert("Невозможно удалить зал, так как он уже используется");
            }
        }
    };

    const handleAddHall = () => {
        setShowForm(true);
    };

    const handleSaveHall = () => {
        setShowForm(false);
        fetchHalls(-1);
    };

    return (
        <div>
            {selectedHall ? (
                <HallDetail
                    hall={selectedHall}
                    rows={rows}
                    onSave={handleSave}
                    onDelete={handleDelete}
                    onBack={() => setSelectedHall(null)}
                />
            ) : (
                <div>
                    <h2>Список залов</h2>
                    <div style={{border:'1px solid darkgray', borderRadius: 5, height: 2, backgroundColor: 'darkgray', marginTop: 10, marginBottom: 13}}></div>
                    <Button style={{marginBottom:10}} onClick={handleAddHall}>Добавить зал</Button>
                    <ListGroup>
                        {halls.map(_hall => (
                            <ListGroup.Item key={_hall.id} action onClick={() => handleSelectHall(_hall)}>
                                {_hall.name}
                            </ListGroup.Item>
                        ))}
                    </ListGroup>
                    <HallForm
                        show={showForm}
                        onHide={() => setShowForm(false)}
                        onSave={handleSaveHall}
                    />
                </div>
            )}
        </div>
    );
};

export default HallManager;
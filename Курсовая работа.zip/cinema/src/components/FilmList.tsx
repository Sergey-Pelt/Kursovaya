import React, { useState, useEffect } from 'react';
import { ListGroup, Button } from 'react-bootstrap';
import axios from './axiosConfig';
import { Film } from './types/Film';
import FilmDetails from './FilmDetails';
import FilmForm from './FilmForm';
import 'bootstrap/dist/css/bootstrap.min.css';

const FilmList: React.FC = () => {
    const [films, setFilms] = useState<Film[]>([]);
    const [selectedFilm, setSelectedFilm] = useState<Film | null>(null);
    const [showForm, setShowForm] = useState<boolean>(false);
    const [isEdit, setIsEdit] = useState<boolean>(false);

    useEffect(() => {
        fetchFilms(-1);
    }, []);

    const fetchFilms = async (id: number) => {
        try {
            const response = await axios.get<Film[]>(`film?id=${id}`);
            setFilms(response.data);
        } catch {
            alert('Не удалось загрузить список фильмов');
        }
    };

    const handleAddFilm = () => {
        setSelectedFilm(null);
        setIsEdit(false);
        setShowForm(true);
    };

    const handleEditFilm = (film: Film) => {
        setSelectedFilm(film);
        setIsEdit(true);
        setShowForm(true);
    };

    const handleDeleteFilm = async (id: number) => {
        try {
            await axios.delete(`film?id=${id}`);
            fetchFilms(-1);
            setSelectedFilm(null);
        } catch (error) {
            alert("Невозможно удалить фильм, так как он уже используется");
        }
    };

    const handleFormSubmit = async (film: Film) => {
        if (isEdit) {
            try {
                await axios.put(`film?id=${film.id}`, film);
            }
            catch {
                alert("Введены неверные или уже существующие данные")
            }
        } 
        else {
            try {
                await axios.post('film', film);
            }
            catch {
                alert("Введены неверные или уже существующие данные")
            }
        }
        fetchFilms(-1);
        setShowForm(false);
        if (isEdit) setSelectedFilm(film);
    };

    return (
        <div>
            {selectedFilm ? (
                <FilmDetails
                    film={selectedFilm}
                    onEdit={handleEditFilm}
                    onDelete={handleDeleteFilm}
                    onBack={() => setSelectedFilm(null)}
                />
            ) : (
                <div>
                    <h2>Список фильмов</h2>
                    <div style={{border:'1px solid darkgray', borderRadius: 5, height: 2, backgroundColor: 'darkgray', marginTop: 10, marginBottom: 13}}></div>
                    <Button style={{marginBottom:10}} variant="primary" onClick={handleAddFilm}>Добавить фильм</Button>
                    <ListGroup>
                        {films.map(film => (
                            <ListGroup.Item key={film.id} action onClick={() => setSelectedFilm(film)}>
                                <div>{`${film.name} ${film.minimalAge}+`}</div>
                                <div>{film.duration}</div>
                            </ListGroup.Item>
                        ))}
                    </ListGroup>
                </div>
            )}
            <FilmForm
                show={showForm}
                film={selectedFilm}
                onSubmit={handleFormSubmit}
                onHide={() => setShowForm(false)}
            />
        </div>
    );
};

export default FilmList;
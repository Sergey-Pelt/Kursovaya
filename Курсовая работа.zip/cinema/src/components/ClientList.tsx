import React, { useState, useEffect } from 'react';
import { ListGroup, Button } from 'react-bootstrap';
import axios from './axiosConfig';
import { Client } from './types/Client';
import ClientDetails from './ClientDetails';
import ClientForm from './ClientForm';
import 'bootstrap/dist/css/bootstrap.min.css';

const ClientList: React.FC = () => {
    const [clients, setClients] = useState<Client[]>([]);
    const [selectedClient, setSelectedClient] = useState<Client | null>(null);
    const [showForm, setShowForm] = useState<boolean>(false);
    const [isEdit, setIsEdit] = useState<boolean>(false);

    useEffect(() => {
        fetchClients(-1);
    }, []);

    const fetchClients = async (id: number) => {
        try {
            const response = await axios.get<Client[]>(`client?id=${id}`);
            setClients(response.data);
        } catch {
            alert('Не удалось загрузить список клиентов');
        }
    };

    const handleAddClient = () => {
        setSelectedClient(null);
        setIsEdit(false);
        setShowForm(true);
    };

    const handleEditClient = (client: Client) => {
        setSelectedClient(client);
        setIsEdit(true);
        setShowForm(true);
    };

    const handleDeleteClient = async (id: number) => {
        try {
            await axios.delete(`client?id=${id}`);
            fetchClients(-1);
            setSelectedClient(null);
        } catch {
            alert('Невозможно удалить клиента');
        }
    };

    const handleFormSubmit = async (client: Client) => {
        if (isEdit) {
            try {
                await axios.put(`client?id=${client.id}`, client);
            }
            catch {
                alert("Введены неверные или уже существующие данные")
            }
        } else {
            try {
                await axios.post('client', client);
            }
            catch {
                alert("Введены неверные или уже существующие данные")
            }
        }
        fetchClients(-1);
        setShowForm(false);
        if (isEdit) setSelectedClient(client);
    };

    return (
        <div>
            {selectedClient ? (
                <ClientDetails
                    client={selectedClient}
                    onEdit={handleEditClient}
                    onDelete={handleDeleteClient}
                    onBack={() => setSelectedClient(null)}
                />
            ) : (
                <div>
                    <h2>Список клиентов</h2>
                    <div style={{border:'1px solid darkgray', borderRadius: 5, height: 2, backgroundColor: 'darkgray', marginTop: 10, marginBottom: 13}}></div>
                    <Button style={{marginBottom:10}} variant="primary" onClick={handleAddClient}>Добавить клиента</Button>
                    <ListGroup>
                        {clients.map(client => (
                            <ListGroup.Item key={client.id} action onClick={() => setSelectedClient(client)}>
                                <div>{`${client.surname} ${client.name} ${client.patronymic || ''}`}</div>
                                <div>{client.email}</div>
                            </ListGroup.Item>
                        ))}
                    </ListGroup>
                </div>
            )}
            <ClientForm
                show={showForm}
                client={selectedClient}
                onSubmit={handleFormSubmit}
                onHide={() => setShowForm(false)}
            />
        </div>
    );
};

export default ClientList;
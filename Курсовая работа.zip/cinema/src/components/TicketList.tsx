import React, { useState } from 'react';
import { ListGroup, Button, Stack } from 'react-bootstrap';
import { Ticket } from './types/Ticket';
import { TicketStatus } from './types/enums';
import axios from './axiosConfig';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Client } from './types/Client';

interface TicketListProps {
    client: Client;
}

const TicketList: React.FC<TicketListProps> = ({ client }) => {
    const [tickets, setTickets] = useState<Ticket[]>([]);
    const [showTickets, setShowTickets] = useState<boolean>(false);

    const handleShowTickets = async () => {
        try {
            const response = await axios.get<Ticket[]>(`ticket/client?clientId=${client.id}`);
            setTickets(response.data);
            setShowTickets(true);
        } catch (error) {
            alert('Не удалось загрузить список билетов');
        }
    };

    const handleHideTickets = () => {
        setShowTickets(false);        
    };

    return (
        <div>
            {showTickets ? (
                <div>
                    <Button variant="outline-info" onClick={handleHideTickets}>Скрыть список билетов</Button>
                    {tickets.length === 0 ? (
                        <h4>Билетов не найдено.</h4>
                    ) : (
                        <ListGroup>
                            {tickets.map(ticket => (
                                <ListGroup.Item key={ticket.id}>
                                    <Stack gap={1} style={{fontSize: 20} }>
                                        <div><strong>Номер билета:</strong> {ticket.id}</div>
                                        <div><strong>Фильм:</strong> {ticket.session.film? ticket.session.film.name : ''}</div>
                                        <div><strong>Время начала сеанса:</strong> {ticket.session.time} {ticket.session.date}</div>
                                        <div><strong>Зал:</strong> {ticket.seat.row.hall.name}</div>
                                        <div><strong>Ряд:</strong> {ticket.seat.row.number}</div>
                                        <div><strong>Место:</strong> {ticket.seat.number}</div>
                                        <div><strong>Цена:</strong> {ticket.price}</div>
                                        <div><strong>Статус:</strong> {TicketStatus[ticket.status]}</div>
                                    </Stack>  
                                </ListGroup.Item>
                            ))}
                        </ListGroup>
                    )}
                </div>
            ) : (
                <div>
                    <Button variant="info" onClick={handleShowTickets}>Показать список билетов</Button>
                </div>
            )}
            
        </div>
    );
};

export default TicketList;
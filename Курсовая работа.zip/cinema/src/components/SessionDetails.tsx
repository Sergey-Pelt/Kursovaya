import React, { useState, useEffect } from 'react';
import { Button, Stack } from 'react-bootstrap';
import { Session } from './types/Session'
import { Row } from './types/Row';
import { Seat } from './types/Seat';
import { Booking } from './types/Booking';
import BookingForm, { TicketDto } from './BookingForm';
import axios from './axiosConfig';
import 'bootstrap/dist/css/bootstrap.min.css';

interface SessionDetailsProps {
    session: Session;
    rows: Row[];
    onEdit: (film: Session) => void;
    onDelete: (id: number) => void;
    onBack: () => void;
}


const SessionDetails: React.FC<SessionDetailsProps> = ({ session, rows, onEdit, onDelete, onBack }) => {
    const [bookings, setBookings] = useState<Booking[]>([]);
    const [selectedBooking, setSelectedBooking] = useState<Booking | null>(null);
    const [selectedSeat, setSelectedSeat] = useState<Seat>();
    const [selectedRow, setSelectedRow] = useState<number>(0);
    const [showForm, setShowForm] = useState(false);

    useEffect(() => {
        fetchBooking();
    }, []);
    
    const fetchBooking = async() => {
        try{
            const response = await axios.get<Booking[]>(`booking/session?sessionId=${session.id}`);
            setBookings(response.data);
        }
        catch{
            alert("не удалось получить список занятых мест");
        }
    }    

    const hadleShowForm = (booking: Booking | undefined, seat: Seat, rowNumber: number) => {

        if (booking) setSelectedBooking(booking);
        else setSelectedBooking(null);
        setSelectedRow(rowNumber);
        setSelectedSeat(seat);
        setShowForm(true);
    }

    const handleFormSubmit = async(booking: Booking, ticket: TicketDto) => {
        try{        
            if (ticket.id > 0){
                await axios.put(`ticket?id=${ticket.id}`, ticket);
            }
            else{
                await axios.post(`ticket`, ticket);
            }
            if (booking.id > 0){
                await axios.put(`booking?id=${booking.id}`, booking);
            }
            else{
                await axios.post(`booking`, booking);
            }
            setShowForm(false);
            fetchBooking();
        }
        catch{
            alert("Введены неверные данные")
        };
    }

    return (
        <div>
            <Stack gap={1} style={{fontSize: 20}}>
                
                <div><Button variant="outline-secondary" onClick={onBack}>К списку сеансов</Button></div>
                <div><strong>Зал:</strong> {session.hall?.name}</div>
                <div><strong>Дата:</strong> {session.date}</div>
                <div><strong>Время:</strong> {session.time}</div>
                <div><strong>Цена за взрослый билет:</strong> {session.priceAdult}</div>
                <div><strong>Цена за детский билет:</strong> {session.priceChild}</div>
                <div><strong>Свободные места</strong></div>
                <div style={{
                    border: '3px solid darkgray',
                    padding: '10px',
                    marginTop: '10px',
                    width: '10',
                    borderRadius: 10
                }}>
                    <div style={{
                        border: '3px solid darkgray',
                        borderRadius: 5,
                        display: 'flex',
                        justifyContent: 'center',
                        alignItems: 'center',
                        backgroundColor: 'lightgray',
                        padding: '10px',
                        marginBottom: '10px',
                        width: '10'
                    }}>
                        <div style={{fontSize: '25px', color: 'gray'}}><strong>Экран</strong></div>
                    </div>
                    <div>
                        {rows.map(row => (
                            <div key={row.id} style={{ display: 'flex', justifyContent: 'center', flexWrap: 'wrap', marginBottom: '10px' }}>
                                {row.seats.filter(seat => seat.rowId === row.id).map(seat => {
                                    const booking = bookings.find(b => b.seatId === seat.id);
                                    let backgroundColor = 'lightgray';

                                    if (booking) {
                                        switch (booking.status) {
                                            case 1:
                                                backgroundColor = 'blue';
                                                break;
                                            case 2:
                                                backgroundColor = 'red';
                                                break;
                                            default:
                                                break;
                                        }
                                    }
                                    return (
                                        <div 
                                            onClick={() => hadleShowForm(booking, seat, row.number)}
                                            key={seat.id} 
                                            style={{
                                                width: '20px',
                                                height: '20px',
                                                borderRadius: 5,
                                                border: '2px solid darkgray',
                                                backgroundColor: backgroundColor,
                                                margin: '2px',
                                                flexShrink: 1,
                                                cursor: 'pointer'
                                            }}
                                        />
                                    );
                                })}
                            </div>
                        ))}
                    </div>
                </div>
                <Stack direction='horizontal' gap={1}>
                    <Button onClick={() => onEdit(session)}>Редактировать</Button>
                    <Button variant="danger" onClick={() => onDelete(session.id)}>Удалить</Button>
                </Stack>
            </Stack>
            
            <BookingForm
                booking={selectedBooking}
                session={session}
                seat={selectedSeat}
                rowNumber={selectedRow}
                show={showForm}
                onSubmit={handleFormSubmit}
                onHide={() => setShowForm(false)}
            />
        </div>
    );
};

export default SessionDetails;
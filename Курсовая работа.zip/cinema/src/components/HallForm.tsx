import React, { useState, useEffect } from 'react';
import { Modal, Form, Button } from 'react-bootstrap';
import { Hall } from './types/Hall';
import { Row } from './types/Row';
import axios from './axiosConfig';
import 'bootstrap/dist/css/bootstrap.min.css';

interface HallFormProps {
    show: boolean;
    onHide: () => void;
    onSave: (name: string | null) => void;
    hall?: Hall;
    rows?: Row[];
}
interface HallDto{
    name: string;
    rowCount: number;
    seatCount: number[];
}
const HallForm: React.FC<HallFormProps> = ({ show, onHide, onSave, hall, rows}) => {
    const [hallName, setHallName] = useState(hall?.name || '');
    const [numRows, setNumRows] = useState(rows?.length || 1);
    const [numSeats, setNumSeats] = useState<number[]>(rows ? rows.map(row => row.seats.length) : []);
    const [validated, setValidated] = useState(false);

    useEffect(() => {
        if (hall) setHallName(hall.name);
        if (rows) {
            setNumRows(rows.length);
            setNumSeats(prev => {
                const newSeats = [...prev];
                for (var i = 0; i < rows.length; i++) {                    
                    if (rows[i] && rows[i].seats) {
                        newSeats[i] = rows[i].seats.length;
                    }
                }
                return newSeats;
            });
        }
    }, [hall, rows]);
    const handleKeyDown = (event: React.KeyboardEvent<HTMLInputElement>) => {
        const validKeys: string[] = [
          'ArrowUp', 'ArrowDown', 'Tab', 'ArrowLeft', 'ArrowRight'
        ];
    
        if (!validKeys.includes(event.key) && !event.key.match(/^[0-9]$/)) {
          event.preventDefault();
        }
    };
    const handleSubmit = async () => {
        if (hallName && numSeats.length >= 1 && !numSeats.some(element => element === 0)) {
            if (!hall){
                let hallDto: HallDto = {
                    name: hallName,
                    rowCount: numRows,
                    seatCount: numSeats
                };
                try{
                    await axios.post(`hall`, hallDto);
                    onSave(null);
                }
                catch{
                    alert("Невозможно изменить зал, так как он уже используется");
                    return;
                }   
            }
            else{
                let newHall: Hall = {
                    id: hall.id,
                    name: hallName
                };
                try{
                    await axios.put(`hall?id=${hall.id}`, newHall);
                    onSave(hallName);
                }
                catch{
                    alert("Не удалось изменить зал")
                }
            }
        }
        else{
            alert('Не все обязательные поля заполнены');
        } 
        setValidated(true);
    };

    return (
        <Modal show={show} onHide={onHide} centered>
            <Modal.Header closeButton>
                <Modal.Title>{hall ? 'Редактировать зал' : 'Добавить зал'}</Modal.Title>
            </Modal.Header>
            <Modal.Body>
            <h5>Обязательные поля отмечены *</h5>
                <Form noValidate validated={validated}>
                    <Form.Group>
                        <Form.Label>Название зала*</Form.Label>
                        <Form.Control
                            type="text"
                            value={hallName}
                            onChange={(e) => setHallName(e.target.value)}
                            required
                        />
                    </Form.Group>
                    {hall ? (
                        <></>
                    ) : (
                        <>
                            <Form.Group>
                                <Form.Label>Количество рядов*</Form.Label>
                                <Form.Control
                                    type="number"
                                    value={numRows}
                                    onChange={(e) => {
                                        try{
                                            const value = parseInt(e.target.value);
                                            if (value > 30 || value < 1) e.preventDefault();
                                            else{
                                                setNumRows(value);
                                                if (rows){
                                                    setNumSeats(() => {
                                                        let newSeats = new Array(value).fill(1);
                                                        for (var i = 0; i < value; i++) {                    
                                                            if (rows[i] && rows[i].seats) newSeats[i] = rows[i].seats.length;
                                                            else newSeats[i] = 1;
                                                        }
                                                        return newSeats;
                                                    });
                                                }
                                                else{
                                                    setNumSeats(prev => {
                                                        let newSeats = new Array(value).fill(1)
                                                        const prevSeats = [...prev];
                                                        for (var i = 0; i < value; i++) {                    
                                                            if (prevSeats[i] > 1) newSeats[i] = prevSeats[i];
                                                            else newSeats[i] = 1;
                                                        }
                                                        return newSeats;
                                                    });
                                                }
                                            }
                                        }
                                        catch { e.preventDefault(); }
                                    }}
                                    onKeyDown={handleKeyDown}
                                />
                            </Form.Group>
                            {Array.from({ length: numRows }, (_, index) => (
                                <Form.Group key={index}>
                                    <Form.Label>Количество мест в ряду {index + 1}*</Form.Label>
                                    <Form.Control
                                        type="number"
                                        value={index < numSeats.length? numSeats[index] : 0}
                                        onChange={(e) => {
                                            try{
                                                const value = parseInt(e.target.value);
                                                if (value > 50 || value < 1) e.preventDefault();
                                                else{
                                                    setNumSeats(prev => {
                                                        const newSeats = [...prev];
                                                        newSeats[index] = value;
                                                        return newSeats;
                                                    });
                                                }
                                            }
                                            catch { e.preventDefault(); }
                                        }}
                                        onKeyDown={handleKeyDown}
                                    />
                                </Form.Group>
                            ))}
                        </>  
                    )}
                </Form>
            </Modal.Body>
            <Modal.Footer>
                <Button variant="secondary" onClick={onHide}>Отмена</Button>
                <Button variant="primary" onClick={handleSubmit}>Сохранить</Button>
            </Modal.Footer>
        </Modal>
    );
};

export default HallForm;

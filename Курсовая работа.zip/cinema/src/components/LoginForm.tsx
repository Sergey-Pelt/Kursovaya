import React, { useState } from "react";
import { Button, Form } from 'react-bootstrap';
import axios from './axiosConfig';
import { User } from './types/User';
import { useNavigate } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import { useDispatch } from 'react-redux';
import { login } from './authSlice';

const LoginForm: React.FC = () => {
    const [formData, setFormData] = useState<User>({
        id: 0,
        login: '',
        password: ''
    });
    const [validated, setValidated] = useState(false);
    const [wrongString, setWrongString] = useState<string | null>(null);
    const navigate = useNavigate();
    const dispatch = useDispatch();

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = e.target;
        setFormData({
            ...formData,
            [name]: value
        });
    }

    const handleSubmit = async(e: React.ChangeEvent<HTMLFormElement>) => {
        e.preventDefault();
        const form = e.currentTarget;
        if (form.checkValidity() === false) {
            e.stopPropagation();
            setValidated(true);
        }
        else{
            try{
                const response = await axios.post(`auth`, formData);
                if (response.status === 200) {
                    localStorage.setItem('isAuthenticated', 'true');
                    localStorage.setItem('user', formData.login)
                    dispatch(login({user: formData.login}));
                    setValidated(true);
                    navigate('/home');
                  }
            } catch {
                setValidated(false);
                setWrongString('Введён неверный логин/пароль.');
            } 
        }
    }

    return(
        <div>
            <h2>Вход в систему</h2>
            <Form noValidate validated={validated} onSubmit={handleSubmit}>
                <Form.Group style={{width:'25vw'}}>
                    <Form.Label>Логин</Form.Label>
                    <Form.Control
                        type="text"
                        name="login"
                        autoComplete="off"
                        value={formData.login}
                        onChange={handleChange}
                        placeholder="Логин"
                        required
                    />
                </Form.Group>
                <Form.Group style={{width:'25vw'}}>
                    <Form.Label>Пароль</Form.Label>
                    <Form.Control
                        type="password"
                        name="password"
                        placeholder="Пароль"
                        value={formData.password}
                        onChange={handleChange}
                        required
                    />
                </Form.Group>
                <div style={{color:'red'}}>{wrongString}</div>
                <Button style={{marginTop:15}} type="submit" variant="primary">Войти</Button>
            </Form>
        </div>
    )
}

export default LoginForm;
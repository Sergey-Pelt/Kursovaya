import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { RootState } from "../store";
import { logout } from './authSlice';
import { Button } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';

const Home: React.FC = () => {
    const { user } = useSelector((state: RootState) => state.auth);
    const dispatch = useDispatch();
    const navigate = useNavigate();

    const handleLogout = () => {
        dispatch(logout());
        localStorage.clear();
        navigate('/login');
    }

    return (
        <div>
            <h2>Добро пожаловать, { user }</h2>
            <Button onClick={handleLogout}>Выйти</Button>
        </div>
    );
  };
  
  export default Home;
import React from 'react';
import './App.css';
import { BrowserRouter as Router, Route, Routes, Link } from 'react-router-dom';
import { Navbar, Nav, Container } from 'react-bootstrap';
import EmployeeList from './components/EmployeeList';
import ClientList from './components/ClientList';
import HallList from './components/HallList';
import FilmList from './components/FilmList';
import LoginForm from './components/LoginForm';
import Home from './components/Home';
import 'bootstrap/dist/css/bootstrap.min.css';
import PrivateRoute from './components/PrivateRoute';

const App: React.FC = () => {
  return (
    <Router>
      <div>
        <Navbar style={{ borderBottom:'3px solid darkgray', fontSize: 18, fontWeight:'bold'}} bg="light" variant="light" expand="lg">
          <Navbar.Brand href="">
            <Nav.Link as={Link} to="/home">
              <img
                src="/logo.png"
                width="140"
                height="40.28"
                className="d-inline-block align-top"
                alt="CineWave logo"
              />
            </Nav.Link>
          </Navbar.Brand>
          <Navbar.Toggle aria-controls="basic-navbar-nav" />
          <Navbar.Collapse id="basic-navbar-nav">
            <Nav className="mr-auto">
              <Nav.Link as={Link} to="/films">Фильмы</Nav.Link>
              <Nav.Link as={Link} to="/halls">Залы</Nav.Link>
              <Nav.Link as={Link} to="/clients">Клиенты</Nav.Link>
              <Nav.Link as={Link} to="/employees">Сотрудники</Nav.Link>
            </Nav>
          </Navbar.Collapse>
        </Navbar>
        <Container className="mt-4 p-4" style={{ backgroundColor: '#f8f9fa', borderRadius: '10px', minHeight: '10vh', border: '3px solid darkgray', width: '90dvw'}}>
          <Routes>
            <Route path="/login" element={<LoginForm />} />
            <Route path="/" element={<PrivateRoute />}>
              <Route path="home" element={<Home />}/>
              <Route path="/films" element={<FilmList />}/>
              <Route path="/halls" element={<HallList />}/>
              <Route path="/clients" element={<ClientList />}/>
              <Route path="/employees" element={<EmployeeList />}/>
            </Route>
          </Routes>
        </Container>
      </div>
    </Router>
  );
}

export default App;

﻿using System;
using System.Collections.Generic;

namespace Cinema_api;

public partial class Row
{
    public int Id { get; set; }

    public int Number { get; set; }

    public int HallId { get; set; }

    public virtual Hall Hall { get; set; } = null!;

    public virtual ICollection<Seat> Seats { get; set; } = new List<Seat>();
}

﻿namespace Cinema_api;

public partial class Hall
{
    public int Id { get; set; }

    public string Name { get; set; } = null!;

    public virtual ICollection<Row> Rows { get; set; } = new List<Row>();

    public virtual ICollection<Session> Sessions { get; set; } = new List<Session>();
}

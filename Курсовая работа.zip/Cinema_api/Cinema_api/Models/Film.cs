﻿namespace Cinema_api;

public partial class Film
{
    public int Id { get; set; }

    public string Name { get; set; } = null!;

    public string? Description { get; set; }

    public TimeOnly? Duration { get; set; }

    public int Genre { get; set; }
    
    public int MinimalAge { get; set; }

    public virtual ICollection<Session> Sessions { get; set; } = new List<Session>();
}

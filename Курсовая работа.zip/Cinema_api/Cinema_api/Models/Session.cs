﻿namespace Cinema_api;

public partial class Session
{
    public int Id { get; set; }

    public TimeOnly Time { get; set; }

    public DateOnly Date { get; set; }

    public decimal PriceAdult { get; set; }

    public decimal? PriceChild { get; set; }

    public int HallId { get; set; }

    public int FilmId { get; set; }

    public virtual ICollection<Booking> Bookings { get; set; } = new List<Booking>();

    public virtual Film Film { get; set; } = null!;

    public virtual Hall Hall { get; set; } = null!;

    public virtual ICollection<Ticket> Tickets { get; set; } = new List<Ticket>();
}

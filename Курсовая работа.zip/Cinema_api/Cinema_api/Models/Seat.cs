﻿namespace Cinema_api;

public partial class Seat
{
    public int Id { get; set; }

    public int Number { get; set; }

    public int RowId { get; set; }

    public virtual ICollection<Booking> Bookings { get; set; } = new List<Booking>();

    public virtual Row Row { get; set; } = null!;

    public virtual ICollection<Ticket> Tickets { get; set; } = new List<Ticket>();
}

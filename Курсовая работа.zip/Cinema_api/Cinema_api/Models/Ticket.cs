﻿namespace Cinema_api;

public partial class Ticket
{
    public int Id { get; set; }

    public DateOnly PurchaseDate { get; set; }

    public decimal Price { get; set; }

    public string TicketCode { get; set; } = null!;

    public string? DiscountCode { get; set; }

    public int? ClientId { get; set; }

    public int SessionId { get; set; }

    public int SeatId { get; set; }

    public int Status { get; set; }

    public virtual Client Client { get; set; } = null!;

    public virtual Seat Seat { get; set; } = null!;

    public virtual Session Session { get; set; } = null!;
}

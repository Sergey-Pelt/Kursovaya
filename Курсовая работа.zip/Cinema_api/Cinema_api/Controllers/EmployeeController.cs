﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Cinema_api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        private readonly CinemaContext context;

        public EmployeeController(CinemaContext context)
        {
            this.context = context;
        }

        [HttpGet]
        public async Task<IActionResult> Get([FromQuery] int id)
        {
            if (id == -1)
            {
                var employees = await context.Employees.ToListAsync();
                return Ok(employees);
            }
            else
            {
                var employee = await context.Employees.FindAsync(id);
                if (employee == null) return NotFound();
                return Ok(employee);
            }
        }

        [HttpPost]
        public async Task<IActionResult> Post(Employee newEmployee)
        {
            context.Employees.Add(newEmployee);
            try
            {
                await context.SaveChangesAsync();
                return Ok();
            }
            catch
            {
                return BadRequest();
            }
        }

        [HttpPut]
        public async Task<IActionResult> Put([FromQuery] int id, [FromBody] Employee newEmployee)
        {
            var employee = await context.Employees.FindAsync(id);
            if (employee == null) return NotFound();

            employee.Name = newEmployee.Name;
            employee.Surname = newEmployee.Surname;
            employee.Patronymic = newEmployee.Patronymic;
            employee.Birthdate = newEmployee.Birthdate;
            employee.Email = newEmployee.Email;
            employee.Phone = newEmployee.Phone;
            employee.Position = newEmployee.Position;
            employee.Salary = newEmployee.Salary;

            try
            {
                await context.SaveChangesAsync();
                return Ok();
            }
            catch
            {
                return BadRequest();
            }
        }

        [HttpDelete]
        public async Task<IActionResult> Delete([FromQuery] int id)
        {
            var employee = await context.Employees.FindAsync(id);
            if (employee == null) return NotFound();
            context.Employees.Remove(employee);
            try
            {
                await context.SaveChangesAsync();
                return Ok();
            }
            catch
            {
                return BadRequest(new { Message = "Невозможно удалить сотрудника" });
            }
        }
    }
}

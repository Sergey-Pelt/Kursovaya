﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Cinema_api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SeatController : ControllerBase
    {
        private readonly CinemaContext context;

        public SeatController(CinemaContext context)
        {
            this.context = context;
        }

        [HttpGet]
        public async Task<IActionResult> Get([FromQuery] int id)
        {
            if (id == -1)
            {
                var seats = await context.Seats.ToListAsync();
                return Ok(seats);
            }
            else
            {
                var seat = await context.Seats.FindAsync(id);
                if (seat == null) return NotFound();
                return Ok(seat);
            }
        }

        [HttpGet("row")]
        public async Task<IActionResult> GetByRowId([FromQuery] int rowId)
        {
            if (!context.Rows.Any(r => r.Id == rowId)) return BadRequest(new { Message = "Указан несуществующий ряд!" });
            var seats = await context.Seats.Where(s => s.RowId == rowId).ToListAsync();
            if (seats == null) return NotFound();
            return Ok(seats);
        }
    }
}

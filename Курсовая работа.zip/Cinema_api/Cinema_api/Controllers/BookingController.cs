﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Cinema_api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BookingController : ControllerBase
    {
        private readonly CinemaContext context;

        public BookingController(CinemaContext context)
        {
            this.context = context;
        }

        [HttpGet]
        public async Task<IActionResult> Get([FromQuery] int id)
        {
            if (id == -1)
            {
                var bookings = await context.Bookings.ToListAsync();
                return Ok(bookings);
            }
            else
            {
                var booking = await context.Bookings.FindAsync(id);
                if (booking == null) return NotFound();
                return Ok(booking);
            }
        }

        [HttpGet("seat")]
        public async Task<IActionResult> GetBySeatId([FromQuery] int seatId)
        {
            if (!context.Seats.Any(s => s.Id == seatId)) return BadRequest(new { Message = "Указано несуществующее место!" });
            var bookings = await context.Bookings.Where(b => b.SeatId == seatId).ToListAsync();
            if (bookings == null) return NotFound();
            return Ok(bookings);
        }

        [HttpGet("session")]
        public async Task<IActionResult> GetBySessionId([FromQuery] int sessionId)
        {
            if (!context.Sessions.Any(s => s.Id == sessionId)) return BadRequest(new { Message = "Указан несуществующий сеанс!" });
            var bookings = await context.Bookings.Where(b => b.SessionId == sessionId).ToListAsync();
            if (bookings == null) return NotFound();
            return Ok(bookings);
        }

        [HttpPost]
        public async Task<IActionResult> Post(BookingDto bookingDto)
        {
            if (!context.Sessions.Any(s => s.Id == bookingDto.SessionId)) return BadRequest(new { Message = "Указан несуществующий сеанс!" });
            if (!context.Seats.Any(s => s.Id == bookingDto.SeatId)) return BadRequest(new { Message = "Указано несуществующее место!" });
            Booking newBooking = new();
            newBooking.SeatId = bookingDto.SeatId;
            newBooking.SessionId = bookingDto.SessionId;
            newBooking.Status = bookingDto.Status;
            context.Bookings.Add(newBooking);
            try
            {
                await context.SaveChangesAsync();
                return Ok();
            }
            catch
            {
                return BadRequest();
            }
        }

        [HttpPut]
        public async Task<IActionResult> Put([FromQuery] int id, [FromBody] BookingDto bookingDto)
        {
            var booking = await context.Bookings.FindAsync(id);
            if (booking == null) return NotFound();
            if (!context.Sessions.Any(s => s.Id == bookingDto.SessionId)) return BadRequest(new { Message = "Указан несуществующий сеанс!" });
            if (!context.Seats.Any(s => s.Id == bookingDto.SeatId)) return BadRequest(new { Message = "Указано несуществующее место!" });

            booking.Status = bookingDto.Status;
            booking.SessionId = bookingDto.SessionId;
            booking.SeatId = bookingDto.SeatId;

            try
            {
                await context.SaveChangesAsync();
                return Ok();
            }
            catch
            {
                return BadRequest();
            }
        }

        [HttpDelete]
        public async Task<IActionResult> Delete([FromQuery] int id)
        {
            var booking = await context.Bookings.FindAsync(id);
            if (booking == null) return NotFound();
            context.Bookings.Remove(booking);
            try
            {
                await context.SaveChangesAsync();
                return Ok();
            }
            catch
            {
                return BadRequest(new { Message = "Невозможно удалить запись о бронировании" });
            }
        }
    }
    public class BookingDto
    {
        public int Id { get; set; }
        public int Status { get; set; }
        public int SessionId { get; set; }
        public int SeatId { get; set; }
    }
}

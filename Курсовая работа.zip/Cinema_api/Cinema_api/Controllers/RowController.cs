﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Cinema_api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RowController : ControllerBase
    {
        private readonly CinemaContext context;

        public RowController(CinemaContext context)
        {
            this.context = context;
        }

        [HttpGet]
        public async Task<IActionResult> Get([FromQuery] int id)
        {
            if (id == -1)
            {
                var rows = await context.Rows.ToListAsync();
                return Ok(rows);
            }
            else
            {
                var row = await context.Rows.FindAsync(id);
                if (row == null) return NotFound();
                return Ok(row);
            }
        }

        [HttpGet("hall")]
        public async Task<IActionResult> GetByHallId([FromQuery] int hallId)
        {
            if (!context.Halls.Any(h => h.Id == hallId)) return BadRequest(new { Message = "Указан несуществующий зал!" }); 
            var rows = await context.Rows.Where(r => r.HallId == hallId).ToListAsync();
            if (rows == null) return NotFound();
            return Ok(rows);
        }
    }
}

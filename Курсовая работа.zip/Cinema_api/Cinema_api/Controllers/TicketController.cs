﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Cinema_api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TicketController : ControllerBase
    {
        private readonly CinemaContext context;

        public TicketController(CinemaContext context)
        {
            this.context = context;
        }

        [HttpGet]
        public async Task<IActionResult> Get([FromQuery] int id)
        {
            if (id == -1)
            {
                var tickets = await context.Tickets.ToListAsync();
                return Ok(tickets);
            }
            else
            {
                var ticket = await context.Tickets.FindAsync(id);
                if (ticket == null) return NotFound();
                return Ok(ticket);
            }
        }

        [HttpGet("session")]
        public async Task<IActionResult> GetBySessionId([FromQuery] int sessionId, [FromQuery] int seatId)
        {
            if (!context.Sessions.Any(s => s.Id == sessionId)) return BadRequest(new { Message = "Указан несуществующий сеанс!" });
            if (!context.Seats.Any(s => s.Id == seatId)) return BadRequest(new { Message = "Указано несуществующее место!" });
            var tickets = await context.Tickets.FirstOrDefaultAsync(t => t.SessionId == sessionId && t.SeatId == seatId);
            if (tickets == null) return NotFound();
            return Ok(tickets);
        }

        [HttpGet("client")]
        public async Task<IActionResult> GetByClientId([FromQuery] int clientId)
        {
            if (!context.Clients.Any(c => c.Id == clientId)) return BadRequest(new { Message = "Указан несуществующий клиент!" });
            var tickets = await context.Tickets
            .Include(t => t.Session)
                .ThenInclude(f => f.Film)
            .Include(t => t.Seat)
                .ThenInclude(s => s.Row)
                    .ThenInclude(r => r.Hall)
            .Where(t => t.ClientId == clientId)
            .Select(t => new
            {
                t.Id,
                t.PurchaseDate,
                t.Price,
                t.TicketCode,
                t.DiscountCode,
                t.Status,
                Client = new
                {
                    t.Client.Id,
                },
                Session = new
                {
                    t.Session.Id,
                    t.Session.Time,
                    t.Session.Date,
                    Film = new
                    {
                        t.Session.Film.Id,
                        t.Session.Film.Name,
                    }
                },
                Seat = new
                {
                    t.Seat.Id,
                    t.Seat.Number,
                    Row = new
                    {
                        t.Seat.Row.Id,
                        t.Seat.Row.Number,
                        Hall = new
                        {
                            t.Seat.Row.Hall.Id,
                            t.Seat.Row.Hall.Name
                        }
                    }
                }
            })
            .ToListAsync();
            if (tickets == null) return NotFound();
            return Ok(tickets);
        }

        [HttpPost]
        public async Task<IActionResult> Post(TicketDto ticketDto)
        {
            if (!context.Seats.Any(s => s.Id == ticketDto.SeatId)) return BadRequest(new { Message = "Указано несуществующее место!" });
            if (!context.Clients.Any(c => c.Id == ticketDto.ClientId)) return BadRequest(new { Message = "Указан несуществующий клиент!" });
            if (!context.Sessions.Any(s => s.Id == ticketDto.SessionId)) return BadRequest(new { Message = "Указан несуществующий сеанс!" });

            Ticket newTicket = new();
            newTicket.Id = ticketDto.Id;
            newTicket.PurchaseDate = DateOnly.Parse(ticketDto.PurchaseDate);
            newTicket.Price = ticketDto.Price;
            newTicket.TicketCode = ticketDto.TicketCode;
            newTicket.DiscountCode = ticketDto.DiscountCode;
            newTicket.ClientId = ticketDto.ClientId;
            newTicket.SessionId = ticketDto.SessionId;
            newTicket.SeatId = ticketDto.SeatId;
            newTicket.Status = ticketDto.Status;
            context.Tickets.Add(newTicket);
            try
            {
                await context.SaveChangesAsync();
                return Ok();
            }
            catch
            {
                return BadRequest();
            }
        }

        [HttpPut]
        public async Task<IActionResult> Put([FromQuery] int id, [FromBody] TicketDto ticketDto)
        {
            var ticket = await context.Tickets.FindAsync(id);
            if (ticket == null) return NotFound();
            if (!context.Seats.Any(s => s.Id == ticketDto.SeatId)) return BadRequest(new { Message = "Указано несуществующее место!" });
            if (!context.Clients.Any(c => c.Id == ticketDto.ClientId)) return BadRequest(new { Message = "Указан несуществующий клиент!" });
            if (!context.Sessions.Any(s => s.Id == ticketDto.SessionId)) return BadRequest(new { Message = "Указан несуществующий сеанс!" });

            ticket.PurchaseDate = DateOnly.Parse(ticketDto.PurchaseDate);
            ticket.Price = ticketDto.Price;
            ticket.TicketCode = ticketDto.TicketCode;
            ticket.DiscountCode = ticketDto.DiscountCode;
            ticket.ClientId = ticketDto.ClientId;
            ticket.SessionId = ticketDto.SessionId;
            ticket.SeatId = ticketDto.SeatId;
            ticket.Status = ticketDto.Status;

            try
            {
                await context.SaveChangesAsync();
                return Ok();
            }
            catch
            {
                return BadRequest();
            }
        }

        [HttpDelete]
        public async Task<IActionResult> Delete([FromQuery] int id)
        {
            var ticket = await context.Tickets.FindAsync(id);
            if (ticket == null) return NotFound();
            context.Tickets.Remove(ticket);
            try
            {
                await context.SaveChangesAsync();
                return Ok();
            }
            catch
            {
                return BadRequest(new { Message = "Невозможно удалить билет" });
            }
        }
    }
    public class TicketDto
    {
        public int Id { get; set; }
        public string PurchaseDate { get; set; }
        public decimal Price { get; set; }
        public string TicketCode { get; set; } = null!;
        public string? DiscountCode { get; set; }
        public int? ClientId { get; set; }
        public int SessionId { get; set; }
        public int SeatId { get; set; }
        public int Status { get; set; }
    }
}

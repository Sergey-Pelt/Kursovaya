﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Cinema_api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SessionController : ControllerBase
    {
        private readonly CinemaContext context;

        public SessionController(CinemaContext context)
        {
            this.context = context;
        }

        [HttpGet]
        public async Task<IActionResult> Get([FromQuery] int id)
        {
            if (id == -1)
            {
                var sessions = await context.Sessions.ToListAsync();
                return Ok(sessions);
            }
            else
            {
                var session = await context.Sessions.FindAsync(id);
                if (session == null) return NotFound();
                return Ok(session);
            }
        }

        [HttpGet("film")]
        public async Task<IActionResult> GetByFilmId([FromQuery] int filmId)
        {
            if (!context.Films.Any(f => f.Id == filmId)) return BadRequest(new { Message = "Указан несуществующий фильм!" });
            var sessions = await context.Sessions
                .Include(s => s.Hall)
                .Where(s => s.FilmId == filmId)
                .Select(s => new
                {
                    s.Id,
                    s.Time,
                    s.Date,
                    s.PriceAdult,
                    s.PriceChild,
                    s.FilmId,
                    s.HallId,
                    Hall = new
                    {
                        s.Hall.Id,
                        s.Hall.Name
                    }
                })
            .ToListAsync();
            if (sessions == null) return NotFound();
            return Ok(sessions);
        }

        [HttpPost]
        public async Task<IActionResult> Post(SessionDto sessionDto)
        {
            
            if (!context.Halls.Any(h => h.Id == sessionDto.HallId)) return BadRequest(new { Message = "Указан несуществующий зал!" });
            if (!context.Films.Any(f => f.Id == sessionDto.FilmId)) return BadRequest(new { Message = "Указан несуществующий фильм!" });
            Session newSession = new();
            newSession.Date = DateOnly.Parse(sessionDto.Date);
            newSession.Time = TimeOnly.Parse(sessionDto.Time);
            newSession.PriceAdult = sessionDto.PriceAdult;
            newSession.PriceChild = sessionDto.PriceChild;
            newSession.HallId = sessionDto.HallId;
            newSession.FilmId = sessionDto.FilmId;
            context.Sessions.Add(newSession);
            try
            {
                await context.SaveChangesAsync();
                return Ok();
            }
            catch
            {
                return BadRequest();
            }
        }

        [HttpPut]
        public async Task<IActionResult> Put([FromQuery] int id, [FromBody] SessionDto sessionDto)
        {
            var session = await context.Sessions.FindAsync(id);
            if (session == null) return NotFound();
            if (!context.Halls.Any(h => h.Id == sessionDto.HallId)) return BadRequest(new { Message = "Указан несуществующий зал!" });
            if (!context.Films.Any(f => f.Id == sessionDto.FilmId)) return BadRequest(new { Message = "Указан несуществующий фильм!" });

            session.Time = TimeOnly.Parse(sessionDto.Time);
            session.Date = DateOnly.Parse(sessionDto.Date);
            session.PriceAdult = sessionDto.PriceAdult;
            session.PriceChild = sessionDto.PriceChild;
            session.HallId = sessionDto.HallId;
            session.FilmId = sessionDto.FilmId;

            try
            {
                await context.SaveChangesAsync();
                return Ok();
            }
            catch
            {
                return BadRequest();
            }
        }

        [HttpDelete]
        public async Task<IActionResult> Delete([FromQuery] int id)
        {
            var session = await context.Sessions.FindAsync(id);
            if (session == null) return NotFound();
            context.Sessions.Remove(session);
            try
            {
                await context.SaveChangesAsync();
                return Ok();
            }
            catch
            {
                return BadRequest(new { Message = "Невозможно удалить сеанс" });
            }
        }
    }
    public class SessionDto
    {
        public string Date { get; set; }
        public string Time { get; set; }
        public int FilmId { get; set; }
        public int HallId { get; set; }
        public int PriceAdult { get; set; }
        public int? PriceChild { get; set; }
    }
}

﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Cinema_api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ClientController : ControllerBase
    {
        private readonly CinemaContext context;

        public ClientController(CinemaContext context)
        {
            this.context = context;
        }

        [HttpGet]
        public async Task<IActionResult> Get([FromQuery] int id)
        {
            if (id == -1)
            {
                var clients = await context.Clients.ToListAsync();
                return Ok(clients);
            }
            else
            {
                var client = await context.Clients.FindAsync(id);
                if (client == null) return NotFound();
                return Ok(client);
            }
        }

        [HttpPost]
        public async Task<IActionResult> Post(Client newClient)
        {
            context.Clients.Add(newClient);
            try
            {
                await context.SaveChangesAsync();
                return Ok();
            }
            catch
            {
                return BadRequest();
            }
        }

        [HttpPut]
        public async Task<IActionResult> Put([FromQuery] int id, [FromBody] Client newClient)
        {
            var client = await context.Clients.FindAsync(id);
            if (client == null) return NotFound();

            client.Name = newClient.Name;
            client.Surname = newClient.Surname;
            client.Patronymic = newClient.Patronymic;
            client.Birthdate = newClient.Birthdate;
            client.Email = newClient.Email;
            client.Phone = newClient.Phone;

            try
            {
                await context.SaveChangesAsync();
                return Ok();
            }
            catch
            {
                return BadRequest();
            }
        }

        [HttpDelete]
        public async Task<IActionResult> Delete([FromQuery] int id)
        {
            var client = await context.Clients.FindAsync(id);
            if (client == null) return NotFound();
            context.Clients.Remove(client);
            try
            {
                await context.SaveChangesAsync();
                return Ok();
            }
            catch
            {
                return BadRequest(new { Message = "Невозможно удалить клиента" });
            }
        }
    }
}

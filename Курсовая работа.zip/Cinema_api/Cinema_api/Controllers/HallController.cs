﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Cinema_api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class HallController : ControllerBase
    {
        private readonly CinemaContext context;

        public HallController(CinemaContext context)
        {
            this.context = context;
        }

        [HttpGet]
        public async Task<IActionResult> Get([FromQuery] int id)
        {
            if (id == -1)
            {
                var halls = await context.Halls.ToListAsync();
                return Ok(halls);
            }
            else
            {
                var hall = await context.Halls.FindAsync(id);
                if (hall == null) return NotFound();
                return Ok(hall);
            }
        }

        [HttpPost]
        public async Task<IActionResult> Post(HallDto hallDto)
        {
            Hall? oldHall = context.Halls.FirstOrDefault(h => h.Name == hallDto.Name);
            if (oldHall != null)
            {
                return BadRequest();
            }
            var newHall = new Hall()
            {
                Name = hallDto.Name
            };
            context.Halls.Add(newHall);
            try
            {
                context.SaveChanges();
                Console.WriteLine($"newHall.Id {newHall.Id}");
                for (int i = 1; i <= hallDto.RowCount; i++)
                {
                    Row row = new Row()
                    {
                        Number = i,
                        HallId = newHall.Id
                    };
                    context.Rows.Add(row);
                }
                context.SaveChanges();
                var rows = context.Rows.Where(r => r.HallId == newHall.Id).ToList();
                for (int i = 0; i < hallDto.RowCount; i++)
                {
                    for (int j = 1; j <= hallDto.SeatCount[i]; j++)
                    {
                        Console.WriteLine($"rows[i].id  {rows[i].Id}");
                        Seat seat = new Seat()
                        {
                            Number = j,
                            RowId = rows[i].Id
                        };
                        context.Seats.Add(seat);
                        context.SaveChanges();
                    }
                }
                return Ok();       
            }
            catch
            {
                return BadRequest();
            }
        }

        [HttpPut]
        public async Task<IActionResult> Put([FromQuery] int id, [FromBody] Hall newHall)
        {
            var hall = await context.Halls.FindAsync(id);
            if (hall == null) return NotFound();

            hall.Name = newHall.Name;

            try
            {
                await context.SaveChangesAsync();
                return Ok();
            }
            catch
            {
                return BadRequest();
            }
        }

        [HttpDelete]
        public async Task<IActionResult> Delete([FromQuery] int id)
        {
            var hall = await context.Halls.FindAsync(id);
            if (hall == null) return NotFound();
            context.Halls.Remove(hall);
            try
            {
                await context.SaveChangesAsync();
                return Ok();
            }
            catch
            {
                return BadRequest(new { Message = "Невозможно удалить зал" });
            }
        }
    }
}
public class HallDto
{
    public string Name { get; set; }
    public int RowCount { get; set; }
    public int[] SeatCount { get; set; }
}

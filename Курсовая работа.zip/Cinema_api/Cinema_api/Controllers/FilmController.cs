﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Cinema_api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class FilmController : ControllerBase
    {
        private readonly CinemaContext context;

        public FilmController(CinemaContext context)
        {
            this.context = context;
        }

        [HttpGet]
        public async Task<IActionResult> Get([FromQuery] int id)
        {
            if (id == -1)
            {
                var films = await context.Films.ToListAsync();
                return Ok(films);
            }
            else
            {
                var film = await context.Films.FindAsync(id);
                if (film == null) return NotFound();
                return Ok(film);
            }
        }

        [HttpPost]
        public async Task<IActionResult> Post(FilmDto filmDto)
        {
            Film film = new();
            film.Name = filmDto.Name;
            film.Description = filmDto.Description;
            film.Duration = TimeOnly.Parse(filmDto.Duration);
            film.Genre = filmDto.Genre;
            Console.WriteLine(film.Genre.ToString());
            film.MinimalAge = filmDto.MinimalAge;
            Console.WriteLine(film.Genre);
            context.Films.Add(film);
            
            try
            {
                await context.SaveChangesAsync();
                return Ok();
            }
            catch
            {
                return BadRequest();
            }
        }

        [HttpPut]
        public async Task<IActionResult> Put([FromQuery] int id, [FromBody] FilmDto filmDto)
        {
            var film = await context.Films.FindAsync(id);
            if (film == null) return NotFound();

            film.Name = filmDto.Name;
            film.Description = filmDto.Description;
            film.Duration = TimeOnly.Parse(filmDto.Duration);
            film.Genre = filmDto.Genre;
            Console.WriteLine(film.Genre.ToString());
            film.MinimalAge = filmDto.MinimalAge;

            try
            {
                await context.SaveChangesAsync();
                return Ok();
            }
            catch
            {
                return BadRequest();
            }
        }

        [HttpDelete]
        public async Task<IActionResult> Delete([FromQuery] int id)
        {
            var film = await context.Films.FindAsync(id);
            if (film == null) return NotFound();
            context.Films.Remove(film);
            try
            {
                await context.SaveChangesAsync();
                return Ok();
            }
            catch
            {
                return BadRequest(new { Message = "Невозможно удалить фильм" });
            }
        }
    }
    public class FilmDto
    {
        public int Id { get; set; }

        public string Name { get; set; }

        public string? Description { get; set; }

        public string? Duration { get; set; }

        public int Genre { get; set; }

        public int MinimalAge { get; set; }
    }
}

﻿using Cinema_api.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Cinema_api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly CinemaContext context;

        public AuthController(CinemaContext context)
        {
            this.context = context;
        }

        [HttpPost]
        public async Task<IActionResult> Login([FromBody] User loginData)
        {
            var user = await context.Users.FirstOrDefaultAsync(u => u.Login == loginData.Login && u.Password == loginData.Password);
            if (user == null) return Unauthorized("Введён неверный логин/пароль");
            return Ok();
        }
    }
}
